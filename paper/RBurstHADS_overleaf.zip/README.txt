R-BurstHADS --- Overleaf package
================================

Upload this whole .zip to Overleaf (New Project -> Upload Project).

Settings
  Main document : main.tex
  Compiler      : pdfLaTeX

Contents
  main.tex          the paper
  figs/*.pdf        six figures, one graph each, single column
  README.txt        this file

What changed from the previous package
--------------------------------------
1. Real IEEEtran instead of ieeelike.sty.
   The old package emulated the IEEE look with a hand-written style file
   because IEEEtran.cls was not available where it was built. Overleaf
   ships IEEEtran, so main.tex now uses \documentclass[conference]{IEEEtran}
   and ieeelike.sty is gone. Delete the old one; do not mix them.

2. Figures are PDFs, already at their final printed size.
   Each is exactly 3.40 in wide -- one column -- and holds ONE graph. They
   are included with NO width= option:

       \includegraphics{fig1_headline.pdf}        <-- correct
       \includegraphics[width=\linewidth]{...}    <-- do NOT do this

   Passing a width rescales the figure and drops its axis labels to about
   4 pt. That is what made the old figures unreadable. If a figure looks
   too small or too large, change the figsize in the generating script and
   rebuild it; never scale it in LaTeX.

3. No two-column figures.
   There is no figure* anywhere, so nothing can be pushed to the end of
   the paper by a backed-up float queue. Every figure is a single-column
   float and lands near its text.

4. All numbers come from the frozen result set.
   Simulator tag freeze-round-b, fingerprint 4f08f48ac35c. The previous
   package's numbers (26.0-39.8% makespan, 14.3-64.3% cheaper, 2,700 runs)
   predate sixteen corrections and must not be reused anywhere.

Still to add before submission
------------------------------
The four appendices are stubs. They need DEVIATIONS.md and the per-cell
confidence-interval tables pasted in from RESULTS_PACK.md.
